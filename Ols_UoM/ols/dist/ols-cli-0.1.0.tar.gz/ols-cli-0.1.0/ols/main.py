# ontology_fetcher/ontology_fetcher/main.py

def main():
    ontology_id = input("Enter the ontology ID: ")
    fetch_ontology_info(ontology_id)

if __name__ == "__main__":
    main()
